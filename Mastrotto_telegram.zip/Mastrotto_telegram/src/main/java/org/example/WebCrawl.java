package org.example;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class WebCrawl {

    private List<Ricetta> ricette;

    public WebCrawl() {
        this.ricette = new ArrayList<>();
    }
    public List<Ricetta> cercaRicette(String alimento, int pagina) {
        try {
            String urlRicerca = "https://www.primochef.it/page/" + pagina + "/?s=" + alimento.replace(" ", "+") + "&refresh_ce"; // Pagine successive
            Document document = Jsoup.connect(urlRicerca).get();
            Elements articoli = document.select("article");

            if (articoli.isEmpty()) {
                return ricette;
            }

            for (Element articolo : articoli) {
                try {
                    if (articolo.selectFirst("div").selectFirst("h3") == null)
                        continue;
                    String titolo = articolo.selectFirst("div").selectFirst("h3").text();
                    String link = articolo.selectFirst("div").selectFirst("h3").selectFirst("a").attr("href");
                    Document ricettaDocument = Jsoup.connect(link).get();
                    Elements caratteristiche = ricettaDocument.selectFirst("ul#cotture-box").select("li");

                    String difficoltà = null;
                    int persone = 0;
                    String preparazione = null;
                    String cottura = null;
                    if (!caratteristiche.isEmpty() && caratteristiche.size() > 0) {
                        Element metaInfo = caratteristiche.get(0).selectFirst(".meta-info");
                        if (metaInfo != null) {
                            difficoltà = metaInfo.text();
                        }
                    }

                    if (caratteristiche.size() > 1) {
                        Element metaInfo = caratteristiche.get(1).selectFirst(".meta-info");
                        if (metaInfo != null) {
                            persone = Integer.parseInt(metaInfo.text());
                        }
                    }

                    if (caratteristiche.size() > 2) {
                        Element metaInfo = caratteristiche.get(2).selectFirst(".meta-info");
                        if (metaInfo != null) {
                            preparazione = metaInfo.text();
                        }
                    }

                    if (caratteristiche.size() > 3) {
                        Element metaInfo = caratteristiche.get(3).selectFirst(".meta-info");
                        if (metaInfo != null) {
                            cottura = metaInfo.text();
                        }
                    }

                    if (difficoltà != null || persone > 0 || preparazione != null || cottura != null) {
                        Ricetta ricetta = new Ricetta(0, titolo, link, difficoltà, persone, preparazione, cottura);
                        this.ricette.add(ricetta);  // Aggiungi la ricetta all'array
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ricette;
    }
}
