package org.example;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {

    private static final String URL = "jdbc:mysql://localhost:3306/telegrambot";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void addUser(Utente utente) {
        if (!isUserRegistered(utente.getChatId())) {
            try (Connection connection = getConnection()) {
                String query = "INSERT INTO utenti (chat_id, username, telefono) VALUES (?, ?, ?)";
                try (PreparedStatement stmt = connection.prepareStatement(query)) {
                    stmt.setLong(1, utente.getChatId());
                    stmt.setString(2, utente.getUsername());
                    stmt.setString(3, utente.getTelefono());
                    stmt.executeUpdate();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("L'utente con chat_id " + utente.getChatId() + " è già registrato.");
        }
    }
    public static boolean isUserRegistered(long chatId) {
        try (Connection connection = getConnection()) {
            String query = "SELECT 1 FROM utenti WHERE chat_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setLong(1, chatId);
                ResultSet rs = stmt.executeQuery();
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static Utente getUserByChatId(long chatId) {
        try (Connection connection = getConnection()) {
            String query = "SELECT * FROM utenti WHERE chat_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setLong(1, chatId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    String username = rs.getString("username");
                    String telefono = rs.getString("telefono");
                    return new Utente(chatId, username, telefono);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public static int aggiungiRicettaAlDatabase(Ricetta ricetta) {
        try (Connection conn = getConnection()) {
            String queryCheck = "SELECT id FROM ricette WHERE link = ?";
            try (PreparedStatement stmt = conn.prepareStatement(queryCheck)) {
                stmt.setString(1, ricetta.getLink());
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }

            String queryInsert = "INSERT INTO ricette (titolo, link, difficoltà, persone, preparazione, cottura) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(queryInsert, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setString(1, ricetta.getTitolo());
                stmt.setString(2, ricetta.getLink());
                stmt.setString(3, ricetta.getDifficoltà());
                stmt.setInt(4, ricetta.getPersone());
                stmt.setString(5, ricetta.getPreparazione());
                stmt.setString(6, ricetta.getCottura());
                stmt.executeUpdate();

                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        return generatedKeys.getInt(1); // Restituisce l'ID generato per la ricetta
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public static Ricetta getRicettaByLink(String link) {
        String query = "SELECT * FROM ricette WHERE link = ?";
        System.out.println("Ricerca nel database per il link: " + link);
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, link);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Ricetta(
                            rs.getInt("id"),
                            rs.getString("titolo"),
                            rs.getString("link"),
                            rs.getString("difficoltà"),
                            rs.getInt("persone"),
                            rs.getString("preparazione"),
                            rs.getString("cottura")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static int getRicettaIdByLink(String link) {
        String query = "SELECT id FROM ricette WHERE link = ?";
        System.out.println("Ricerca nel database per il link: " + link);
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, link);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
    public static List<Ricetta> getRicetteByUserId(long chatId) {
        List<Ricetta> ricette = new ArrayList<>();
        String query = "SELECT * FROM ricette WHERE id IN (SELECT ricetta_id FROM preferiti WHERE chat_id = ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setLong(1, chatId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Ricetta ricetta = new Ricetta(
                            rs.getInt("id"),
                            rs.getString("titolo"),
                            rs.getString("link"),
                            rs.getString("difficoltà"),
                            rs.getInt("persone"),
                            rs.getString("preparazione"),
                            rs.getString("cottura")
                    );
                    ricette.add(ricetta);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ricette;
    }

    public static void addFoodtoDatabase(Utente utente) {
        String query = "INSERT INTO alimenti (food_name, chat_id, expiry_date) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, utente.getFoodName());
            ps.setLong(2, utente.getChatId());
            ps.setDate(3, java.sql.Date.valueOf(utente.getExpiryDate())); // Converte LocalDate in java.sql.Date
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static boolean addRicettaPreferita(long chatId, int ricettaId) {
        String query = "INSERT INTO preferiti (chat_id, ricetta_id) VALUES (?, ?)";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setLong(1, chatId);
            statement.setInt(2, ricettaId);
            System.out.println("Inserimento nei preferiti - ChatID: " + chatId + ", RicettaID: " + ricettaId);
            return statement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public static void removeExpiredFood() {
        String query = "DELETE FROM alimenti WHERE expiry_date < CURDATE()";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement ps = conn.prepareStatement(query)) {
            int rowsAffected = ps.executeUpdate();
            System.out.println("Alimenti scaduti rimossi: " + rowsAffected);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static List<Alimento> getAlimentiInVendita(long chatId) {
        List<Alimento> alimentiInVendita = new ArrayList<>();
        String query = "SELECT a.food_name, a.expiry_date, u.username, u.telefono " +
                "FROM alimenti a " +
                "INNER JOIN utenti u ON a.chat_id = u.chat_id " +
                "WHERE a.chat_id != ?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setLong(1, chatId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String nome = rs.getString("food_name");
                    Date expiryDate = rs.getDate("expiry_date");
                    String username = rs.getString("username");
                    String telefono = rs.getString("telefono");

                    Alimento alimento = new Alimento(nome, expiryDate);
                    alimento.setUsername(username);
                    alimento.setTelefono(telefono);

                    alimentiInVendita.add(alimento);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return alimentiInVendita;
    }
}
