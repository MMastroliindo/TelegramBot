package org.example;

public class Ricetta {
    private String titolo;
    private String link;
    private String difficoltà;
    private int persone;
    private String preparazione;
    private String cottura;
    private int id;

    // Costruttore per inizializzare la ricetta
    public Ricetta(int id, String titolo, String link, String difficoltà, int persone, String preparazione, String cottura) {
        this.titolo = titolo;
        this.link = link;
        this.difficoltà = difficoltà;
        this.persone = persone;
        this.preparazione = preparazione;
        this.cottura = cottura;
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getDifficoltà() {
        return difficoltà;
    }

    public void setDifficoltà(String difficoltà) {
        this.difficoltà = difficoltà;
    }

    public int getPersone() {
        return persone;
    }

    public void setPersone(int persone) {
        this.persone = persone;
    }

    public String getPreparazione() {
        return preparazione;
    }

    public void setPreparazione(String preparazione) {
        this.preparazione = preparazione;
    }

    public String getCottura() {
        return cottura;
    }

    public void setCottura(String cottura) {
        this.cottura = cottura;
    }

    public int getId() {
        return id; // Ritorna l'ID assegnato dal database
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDifficolta() {
        return difficoltà;
    }
}
