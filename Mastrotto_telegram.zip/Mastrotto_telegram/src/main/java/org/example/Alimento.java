package org.example;

import java.util.Date;

public class Alimento {
    private int id;
    private String nome;
    private Date dataScadenza;
    private String username;
    private String telefono;

    // Costruttore
    public Alimento(String nome, Date dataScadenza) {
        this.nome = nome;
        this.dataScadenza = dataScadenza;
    }

    public String getNome() {
        return nome;
    }

    public Date getScadenza() {
        return dataScadenza;
    }

    // Nuovo Getter e Setter per l'username
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Alimento [ID=" + id + ", nome=" + nome + ", data di scadenza=" + dataScadenza
                + ", username=" + username + ", telefono=" + telefono + "]";
    }
}
