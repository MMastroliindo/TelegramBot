package org.example;

import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;

public class Main {

    public static void main(String[] args) {
        // Rimuove gli alimenti scaduti dal database
        DatabaseManager.removeExpiredFood();

        try {
            TelegramBotsApi apiBot = new TelegramBotsApi(DefaultBotSession.class);
            apiBot.registerBot(new RicetteTelegramBot());
            System.out.println("Bot avviato correttamente!");
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }
}
