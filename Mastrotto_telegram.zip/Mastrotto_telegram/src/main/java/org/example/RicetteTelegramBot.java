package org.example;

import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class RicetteTelegramBot extends TelegramLongPollingBot {

    private static final String BOT_USERNAME = "FoodCycleBot";  // Nome del bot
    private static final String BOT_TOKEN = "7243274632:AAGl-MuJ2zH45dxz1rB3X8vm9MoftoQnoHg"; // Token del bot
    private HashSet<Utente> utenti = new HashSet<>(); // Gestione utenti in memoria

    @Override
    public String getBotUsername() {
        return BOT_USERNAME;
    }

    @Override
    public String getBotToken() {
        return BOT_TOKEN;
    }

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage() && update.getMessage().hasText()) {
            handleTextMessage(update);
        } else if (update.hasCallbackQuery()) {
            handleCallbackQuery(update);
        }
    }


    private void handleTextMessage(Update update) {
        Message message = update.getMessage();
        String chatId = message.getChatId().toString();
        String userMessage = message.getText().trim();

        Utente utente = getUtente(Long.parseLong(chatId));

        if (userMessage.equalsIgnoreCase("/start")) {
            startProcess(chatId, utente);
        } else if (userMessage.equalsIgnoreCase("/help")) {
            sendMessage(chatId, "Comandi disponibili:\n/start - Inizia a interagire con il bot\n/help - Ottieni una lista dei comandi disponibili\n/my_recipes - Visualizza le tue ricette preferite\n/add_expiration - Aggiungi un alimento in scadenza\n/search_recipes - Cerca ricette in base agli ingredienti");
        } else if (userMessage.equalsIgnoreCase("/option")) {
            showWelcomeMessage(chatId); // Mostra il messaggio con le opzioni disponibili
        } else if ("awaiting_username".equals(utente.getUserState())) {
            handleUsernameInput(chatId, userMessage, utente);
        } else if ("awaiting_phone".equals(utente.getUserState())) {
            handlePhoneInput(chatId, userMessage, utente);
        } else if ("idle".equals(utente.getUserState())) {
            handleSearch(chatId, userMessage);
        } else if ("awaiting_food_name".equals(utente.getUserState())) {
            handleFoodNameInput(chatId, userMessage, utente);
        } else if ("awaiting_expiry_date".equals(utente.getUserState())) {
            handleExpiryDateInput(chatId, userMessage, utente);
        } else {
            sendMessage(chatId, "Devi completare la registrazione per cercare ricette. Usa il comando /start per accedere.");
        }
    }

    private void handleCallbackQuery(Update update) {
        String callbackData = update.getCallbackQuery().getData();
        String chatId = update.getCallbackQuery().getMessage().getChatId().toString();

        switch (callbackData) {
            case "start_bot":
                startProcess(chatId, getUtente(Long.parseLong(chatId)));
                break;
            case "search_recipes":
                sendMessage(chatId, "Inserisci gli ingredienti o il nome della ricetta che desideri cercare.");
                getUtente(Long.parseLong(chatId)).setUserState("idle");
                break;
            case "view_my_recipes":
                showUserRecipes(chatId);
                break;
            case "add_expiration":
                getUtente(Long.parseLong(chatId)).setUserState("awaiting_food_name");
                sendMessage(chatId, "Per favore, inviami il nome dell'alimento.");
                break;
            case "view_food_for_sale":
                showFoodForSale(chatId);
                break;
            default:
                if (callbackData.startsWith("add_favorite_")) {
                    handleAddToFavorites(chatId, callbackData);
                }
        }
    }

    private void showUserRecipes(String chatId) {
        List<Ricetta> ricette = DatabaseManager.getRicetteByUserId(Long.parseLong(chatId));

        if (ricette.isEmpty()) {
            sendMessage(chatId, "Non hai ancora salvato alcuna ricetta.");
        } else {
            for (Ricetta ricetta : ricette) {
                StringBuilder message = new StringBuilder();
                message.append("Titolo: ").append(ricetta.getTitolo()).append("\n")
                        .append("Link: ").append(ricetta.getLink()).append("\n")
                        .append("Difficoltà: ").append(ricetta.getDifficoltà()).append("\n")
                        .append("Persone: ").append(ricetta.getPersone()).append("\n")
                        .append("Preparazione: ").append(ricetta.getPreparazione()).append("\n")
                        .append("Cottura: ").append(ricetta.getCottura()).append("\n");

                // Invia un messaggio per ogni ricetta separatamente
                sendMessage(chatId, message.toString());
            }
        }
    }

    private void startProcess(String chatId, Utente utente) {
        if (utente.getUsername() == null || utente.getTelefono() == null) {
            sendMessage(chatId, "");
            sendMessage(chatId, "Per favore inviami il tuo username.");
            utente.setUserState("awaiting_username");
        } else {
            showWelcomeMessage(chatId);
        }
    }

    private void handleFoodNameInput(String chatId, String foodName, Utente utente) {
        utente.setFoodName(foodName); // Imposta il nome dell'alimento
        utente.setUserState("awaiting_expiry_date");
        sendMessage(chatId, "Ora inviami la data di scadenza (formato: YYYY-MM-DD).");
    }

    private void handleExpiryDateInput(String chatId, String expiryDate, Utente utente) {
        try {
            LocalDate date = LocalDate.parse(expiryDate); // Converte la data nel formato LocalDate
            utente.setExpiryDate(date); // Imposta la data di scadenza
            DatabaseManager.addFoodtoDatabase(utente); // Aggiungi l'alimento nel database
            sendMessage(chatId, "Alimento aggiunto correttamente!");
            utente.setUserState("idle"); // Ripristina lo stato dell'utente
        } catch (DateTimeParseException e) {
            sendMessage(chatId, "Formato data non valido. Usa il formato YYYY-MM-DD.");
        }
    }

    private void showWelcomeMessage(String chatId) {
        String welcomeMessage = "Benvenuto nel nostro bot per ridurre lo spreco alimentare! 🍎🥕\n\n" +
                "Questo bot ti aiuta a gestire gli alimenti disponibili a casa, trovare ricette basate sugli ingredienti che hai " +
                "in casa che stanno per scadere. Inoltre, puoi condividere il cibo in eccesso con la tua comunità locale!\n\n" +
                "Durante l'utilizzo puoi digitare il comando /option per vedere tutte le opzioni disponibili.\n" +
                "Scegli un'opzione per iniziare:";

        InlineKeyboardMarkup keyboardMarkup = new InlineKeyboardMarkup();
        List<List<InlineKeyboardButton>> keyboard = new ArrayList<>();

        InlineKeyboardButton searchRecipesButton = new InlineKeyboardButton();
        searchRecipesButton.setText("Cerca ricette");
        searchRecipesButton.setCallbackData("search_recipes");

        InlineKeyboardButton addExpirationButton = new InlineKeyboardButton();
        addExpirationButton.setText("Aggiungi alimento in scadenza");
        addExpirationButton.setCallbackData("add_expiration");

        InlineKeyboardButton viewRecipesButton = new InlineKeyboardButton();
        viewRecipesButton.setText("Visualizza ricette preferite");
        viewRecipesButton.setCallbackData("view_my_recipes");

        InlineKeyboardButton viewFoodForSaleButton = new InlineKeyboardButton();
        viewFoodForSaleButton.setText("Vedi alimenti in vendita");
        viewFoodForSaleButton.setCallbackData("view_food_for_sale");

        List<InlineKeyboardButton> row1 = new ArrayList<>();
        row1.add(searchRecipesButton);
        keyboard.add(row1);

        List<InlineKeyboardButton> row2 = new ArrayList<>();
        row2.add(addExpirationButton);
        keyboard.add(row2);

        List<InlineKeyboardButton> row3 = new ArrayList<>();
        row3.add(viewRecipesButton);
        keyboard.add(row3);

        List<InlineKeyboardButton> row4 = new ArrayList<>();
        row4.add(viewFoodForSaleButton);
        keyboard.add(row4);

        keyboardMarkup.setKeyboard(keyboard);

        sendMessage(chatId, welcomeMessage, keyboardMarkup);
    }


    private void showFoodForSale(String chatId) {
        List<Alimento> alimentiInVendita = DatabaseManager.getAlimentiInVendita(Long.parseLong(chatId));

        if (alimentiInVendita.isEmpty()) {
            sendMessage(chatId, "Non ci sono alimenti in vendita al momento.");
        } else {
            for (Alimento alimento : alimentiInVendita) {
                StringBuilder message = new StringBuilder();
                message.append("Alimento: ").append(alimento.getNome()).append("\n")
                        .append("Scadenza: ").append(alimento.getScadenza()).append("\n")
                        .append("Username del venditore: ").append(alimento.getUsername()).append("\n")
                        .append("Telefono del venditore: ").append(alimento.getTelefono()).append("\n");

                // Invia un messaggio per ogni alimento in vendita
                sendMessage(chatId, message.toString());
            }
        }
    }

    private void handleUsernameInput(String chatId, String username, Utente utente) {
        utente.setUsername(username);
        utente.setUserState("awaiting_phone");
        sendMessage(chatId, "Ora inviami il tuo numero di telefono.");
    }

    private void handlePhoneInput(String chatId, String phone, Utente utente) {
        utente.setTelefono(phone);

        if (!userExistsInDatabase(chatId)) {
            DatabaseManager.addUser(utente);
        }

        utente.setUserState("idle");
        sendMessage(chatId, "Registrazione completata! Puoi ora utilizzare le funzionalità del telegrambot.");
        showWelcomeMessage(chatId);
    }

    private boolean userExistsInDatabase(String chatId) {
        return DatabaseManager.getUserByChatId(Long.parseLong(chatId)) != null;
    }

    private void handleSearch(String chatId, String query) {
        if (query.isEmpty()) {
            sendMessage(chatId, "Inserisci un ingrediente o il nome della ricetta per effettuare una ricerca.");
            return;
        }

        WebCrawl webCrawl = new WebCrawl();
        List<Ricetta> ricetteTrovate = webCrawl.cercaRicette(query, 1);

        if (ricetteTrovate != null && !ricetteTrovate.isEmpty()) {
            for (Ricetta ricetta : ricetteTrovate) {
                DatabaseManager.aggiungiRicettaAlDatabase(ricetta);

                StringBuilder risposta = new StringBuilder();
                risposta.append("Titolo: ").append(ricetta.getTitolo()).append("\n")
                        .append("Link: ").append(ricetta.getLink()).append("\n")
                        .append("Difficoltà: ").append(ricetta.getDifficoltà()).append("\n")
                        .append("Persone: ").append(ricetta.getPersone()).append("\n")
                        .append("Preparazione: ").append(ricetta.getPreparazione()).append("\n")
                        .append("Cottura: ").append(ricetta.getCottura()).append("\n");

                sendMessage(chatId, risposta.toString(), createAddToFavoritesButton(ricetta));
            }
        } else {
            sendMessage(chatId, "Non sono state trovate ricette per la tua ricerca.");
        }
    }

    private InlineKeyboardMarkup createAddToFavoritesButton(Ricetta ricetta) {
        if (ricetta.getLink() == null || ricetta.getLink().isEmpty()) {
            System.out.println("Errore: il link della ricetta è vuoto. Impossibile creare il bottone.");
            return null; // Non creare un bottone se il link è invalido
        }

        String link = ricetta.getLink();
        String callbackData = "add_favorite_" + link;

        InlineKeyboardMarkup keyboardMarkup = new InlineKeyboardMarkup();
        List<List<InlineKeyboardButton>> keyboard = new ArrayList<>();

        List<InlineKeyboardButton> row1 = new ArrayList<>();
        InlineKeyboardButton addFavoriteButton = new InlineKeyboardButton("⭐ Aggiungi ai preferiti");
        addFavoriteButton.setCallbackData(callbackData);
        row1.add(addFavoriteButton);

        keyboard.add(row1);
        keyboardMarkup.setKeyboard(keyboard);
        return keyboardMarkup;
    }

    private void handleAddToFavorites(String chatId, String callbackData) {
        System.out.println("Callback Data ricevuto: " + callbackData);

        if (!callbackData.startsWith("add_favorite_")) {
            sendMessage(chatId, "Errore: il formato del callback è errato.");
            return;
        }

        String ricettaLink = callbackData.substring("add_favorite_".length());
        System.out.println("Ricetta Link Estratto: " + ricettaLink);

        if (ricettaLink.isEmpty()) {
            sendMessage(chatId, "Errore: il link della ricetta non è valido.");
            return;
        }

        Utente utente = getUtente(Long.parseLong(chatId));

        if (utente != null) {
            Ricetta ricetta = DatabaseManager.getRicettaByLink(ricettaLink);
            if (ricetta == null) {
                System.out.println("Ricetta non trovata nel database per il link: " + ricettaLink); // DEBUG
                sendMessage(chatId, "Errore: la ricetta non è stata trovata nel database.");
                return;
            }
            int id = DatabaseManager.getRicettaIdByLink(ricettaLink);
            boolean isAddedToFavorites = DatabaseManager.addRicettaPreferita(Long.parseLong(chatId), id);
            if (isAddedToFavorites) {
                sendMessage(chatId, "Ricetta aggiunta ai preferiti! ⭐");
            } else {
                sendMessage(chatId, "Errore nell'aggiungere la ricetta ai preferiti.");
            }
        } else {
            sendMessage(chatId, "Errore: utente non trovato.");
        }
    }

    private Utente getUtente(long chatId) {
        return utenti.stream()
                .filter(utente -> utente.getChatId() == chatId)
                .findFirst()
                .orElseGet(() -> {
                    Utente utente = new Utente(chatId);
                    utenti.add(utente);
                    return utente;
                });
    }

    private void sendMessage(String chatId, String messageText) {
        SendMessage message = new SendMessage();
        message.setChatId(chatId);
        message.setText(messageText);
        try {
            execute(message);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    private void sendMessage(String chatId, String text, InlineKeyboardMarkup keyboardMarkup) {
        SendMessage sendMessage = new SendMessage(chatId, text);
        if (keyboardMarkup != null) {
            sendMessage.setReplyMarkup(keyboardMarkup);
        }
        try {
            execute(sendMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }
}