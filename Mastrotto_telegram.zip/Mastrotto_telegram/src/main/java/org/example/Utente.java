package org.example;
import java.time.LocalDate;
import java.util.List;

public class Utente {
    private long chatId;
    private String username;
    private String telefono;
    private String userState;

    private String foodName;
    private LocalDate expiryDate;
    public Utente(long chatId, String username, String telefono) {
        this.chatId = chatId;
        this.username = username;
        this.telefono = telefono;
    }

    // Costruttore che inizializza solo chatId
    public Utente(long chatId) {
        this.chatId = chatId;
    }

    public long getChatId() {
        return chatId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getUserState() {
        return userState;
    }

    public void setUserState(String userState) {
        this.userState = userState;
    }


    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    // Getter e setter per expiryDate
    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;  // Imposta la data di scadenza
    }
}
